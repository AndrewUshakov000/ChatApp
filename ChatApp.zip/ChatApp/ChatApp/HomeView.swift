//
//  HomeView.swift
//  Chat
//
//  Created by Andrew Ushakov on 7/24/22.
//

import SwiftUI

struct HomeView: View {
    static let tag: String? = "Home"
    
    @State private var startNewConversation = false
    @State var navigationToChatLogView = false

    @State private var selectedUser: User?

    @EnvironmentObject var firebaseManager: FirebaseManager

    var body: some View {
        NavigationView {
            VStack {
                HStack(spacing: 16) {
                    AsyncImage(url: URL(string: firebaseManager.user?.profileImageURL ?? "")) { phase in
                        if let image = phase.image {
                            image
                                .resizable()
                                .clipShape(Circle())
                                .overlay(Circle().stroke(lineWidth: 1))
                                .frame(width: 45, height: 45)

                        } else {
                            Image(systemName: "person.fill")
                                .font(.system(size: 34, weight: .bold))
                        }
                    }
                        
                    VStack(alignment: .leading, spacing: 4) {
                        Text(firebaseManager.user?.email.replacingOccurrences(of: "@gmail.com", with: "") ?? "")
                            .font(.system(size: 24, weight: .bold))
                        
                        HStack {
                            Circle()
                                .foregroundColor(.green)
                                .frame(width: 14, height: 14)
                            Text("Online")
                                .font(.system(size: 12))
                                .foregroundColor(Color(.lightGray))
                        }
                    }
                    
                    Spacer()
                    
                    Button {
                        withAnimation {
                            firebaseManager.signOut()
                        }
                    } label: {
                        Image(systemName: "door.right.hand.open")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(Color(.label))
                    }
                }.padding()
                
                ScrollView(showsIndicators: false) {

                    Divider()
                        .padding(.horizontal)

                    ForEach(firebaseManager.recentMessages) { recentMessage in
                        NavigationLink(destination: MessageView(recipient: User(uid: recentMessage.toId, profileImageURL: recentMessage.profileImageURL, email: recentMessage.email))) {
                            VStack {
                                HStack(spacing: 16) {
                                    AsyncImage(url: URL(string: recentMessage.profileImageURL)) { phase in
                                        if let image = phase.image {
                                            image
                                                .resizable()
                                                .clipShape(Circle())
                                                .overlay(Circle().stroke(Color(.label), lineWidth: 1))
                                                .frame(width: 55, height: 55)

                                        } else {
                                            Image(systemName: "person.fill")
                                                .font(.system(size: 34, weight: .bold))
                                                .foregroundColor(Color(.label))
                                        }
                                    }
                                        
                                    VStack(alignment: .leading) {
                                        Text(recentMessage.email)
                                            .font(.system(size: 15, weight: .bold))
                                            .foregroundColor(Color(.label))
                                            .offset(y: -4)
                                        
                                        Text(recentMessage.text)
                                            .font(.system(size: 14))
                                            .foregroundColor(Color(.darkGray))
                                            .multilineTextAlignment(.leading)
                                            .lineLimit(2)
                                            .offset(y: 4)

                                    }
                                    
                                    Spacer()
                                    
                                    Text(recentMessage.time)
                                        .font(.system(size: 14, weight: .semibold))
                                        .foregroundColor(Color(.label))
                                    
                                }.padding(.top, 8)
                            }
                        }

                        Divider()
                            .padding(.top, 8)

                    }.padding(.horizontal)
                    
                }.padding(.bottom, 50)
                
                NavigationLink("", destination: MessageView(recipient: selectedUser ?? User.default), isActive: $navigationToChatLogView)
            }
            .overlay(
                Button {
                    self.startNewConversation.toggle()
                } label: {
                    HStack {
                        Spacer()
                        Text("+ New Message")
                            .font(.system(size: 16, weight: .bold))
                        Spacer()
                    }
                    .foregroundColor(.white)
                    .padding(.vertical)
                    .background(Color.blue)
                    .cornerRadius(24)
                    .padding(.horizontal)
                    .shadow(radius: 15)
                    .offset(y: -10)
                }, alignment: .bottom
            )
            .navigationBarBackButtonHidden()
            .fullScreenCover(isPresented: $startNewConversation) {
                StartNewConversationView(selectedUser: { user in
                    self.selectedUser = user
                    self.navigationToChatLogView.toggle()
                })
            }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
