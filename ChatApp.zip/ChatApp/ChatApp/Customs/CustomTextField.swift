//
//  CustomTextField.swift
//  TwitterApp
//
//  Created by Andrew Ushakov on 6/15/22.
//

import SwiftUI

struct CustomTextField: View {
    @Binding var text: String

    let imageName: String
    let placeholderText: String
    let secure: Bool

    var body: some View {
        VStack {
            HStack {
                Image(systemName: imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                    .foregroundColor(Color(.darkGray))

                if secure {
                    SecureField(placeholderText, text: $text)
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)
                } else {
                    TextField(placeholderText, text: $text)
                        .textInputAutocapitalization(.never)
                        .disableAutocorrection(true)
                }
            }

            Divider()
                .background(Color(.darkGray))
        }
    }
}
