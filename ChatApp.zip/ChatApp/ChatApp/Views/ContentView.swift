//
//  ContentView.swift
//  Chat
//
//  Created by Andrew Ushakov on 9/3/21.
//

import SwiftUI

struct ContentView: View {
    @SceneStorage("selectedView") var selectedView: String?
    @EnvironmentObject var authController: AuthController

    var body: some View {
        if authController.user != nil {
            TabView(selection: $selectedView) {
                HomeView()
                    .tag(HomeView.tag)
                    .tabItem {
                        VStack {
                            Image(systemName: "message")
                            Text("Chats")
                        }
                    }

                SettingsView()
                    .tag(SettingsView.tag)
                    .tabItem {
                        VStack {
                            Image(systemName: "gear")
                            Text("Settings")
                        }
                }
            }
        } else {
            LoginView()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
