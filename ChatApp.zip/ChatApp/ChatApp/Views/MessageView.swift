//
//  MessageView.swift
//  Chat
//
//  Created by Andrew Ushakov on 7/25/22.
//

import SwiftUI

struct MessageView: View {
    @EnvironmentObject var messageController: MessageController
    @EnvironmentObject var authController: AuthController

    @Environment(\.presentations) var presentations

    @FocusState private var isFocused

    @State private var text = ""
    @State var recipient: User

    let columns = [GridItem(.flexible(minimum: 10))]

    var body: some View {
        VStack(spacing: 0) {
            ScrollViewReader { proxy in
                ScrollView(showsIndicators: false) {
                    ForEach(messageController.messages) { message in
                        HStack {
                            ZStack {
                                Text(message.text)
                                    .foregroundColor(.white)
                                    .padding(.horizontal)
                                    .padding(.vertical, 12)
                                    .background(
                                        message.fromId == recipient.uid ?
                                        Color.green.opacity(0.9)
                                        :
                                        Color.blue.opacity(0.9)
                                    )
                                    .cornerRadius(13)
                            }
                            .frame(width: 250, alignment: message.fromId == recipient.uid ? .leading : .trailing)
                        }
                        .frame(maxWidth: .infinity, alignment: message.fromId == recipient.uid ? .leading : .trailing)
                    }
                    .padding(.horizontal)

                    HStack { Spacer() }
                        .id("Empty")

                }
                .padding(.vertical)
                .onReceive(messageController.$scrollId) { _ in
                    withAnimation {
                        proxy.scrollTo("Empty", anchor: .bottom)
                    }
                }
            }

            VStack {
                HStack {
                    TextField("Message...", text: $text)
                        .padding(.horizontal, 10)
                        .frame(height: 37)
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 13))
                        .focused($isFocused)

                    Button {
                        messageController.sendMessages(
                            text: text,
                            sender: authController.user!,
                            recipient: recipient
                        )
                        text = ""
                    } label: {
                        Image(systemName: "paperplane.fill")
                            .foregroundColor(.white)
                            .frame(width: 37, height: 37)
                            .background(
                                Circle()
                                    .foregroundColor(text.isEmpty ? .gray : .blue)
                            )
                    }

                }
            }
            .padding()
            .background(.thickMaterial)
            .navigationBarTitle(recipient.email, displayMode: .inline)
        }

        .padding(.top, 1)
        .task {
            messageController.fetchMessages(recipient: recipient)
        }
        .onDisappear {
            messageController.messageListener?.remove()

            presentations.forEach {
                $0.wrappedValue = false
            }
        }
    }
}
