//
//  CreateNewMessageView.swift
//  Chat
//
//  Created by Andrew Ushakov on 8/8/22.
//

import SwiftUI

struct StartNewConversationView: View {
    let selectedUser: (User) -> ()
    
    @EnvironmentObject var firebaseManager: FirebaseManager
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationView {
            ScrollView(showsIndicators: false) {
                ForEach(firebaseManager.users) { user in
                    Button {
                        dismiss()
                        selectedUser(user)
                    } label: {
                        VStack {
                            HStack(spacing: 16) {
                                AsyncImage(url: URL(string: user.profileImageURL)) { phase in
                                    if let image = phase.image {
                                        image
                                            .resizable()
                                            .clipShape(Circle())
                                            .overlay(Circle().stroke(lineWidth: 1).foregroundColor(Color(.label)))
                                            .frame(width: 45, height: 45)
                                        
                                    } else {
                                        Image(systemName: "person.fill")
                                            .font(.system(size: 34, weight: .bold))
                                            .foregroundColor(Color(.label))
                                    }
                                }
                                
                                Text(user.email)
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(Color(.label))
                                
                                Spacer()
                                
                            }.padding(.top, 8)
                        }
                }

                Divider()
                    .padding(.top, 8)
                    
                }.padding(.horizontal)
                
            }.padding(.bottom, 50)
            .navigationTitle("New Message")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .navigationBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Text("Cancel")
                    }
                }
            }
        }
    }
}
