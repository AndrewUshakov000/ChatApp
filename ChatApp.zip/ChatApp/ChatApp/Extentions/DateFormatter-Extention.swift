//
//  DateFormatter-Extention.swift
//  Chat
//
//  Created by Andrew Ushakov on 8/8/22.
//

import SwiftUI

extension Date {
    func formatted() -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        return formatter.string(from: self)
    }
}

extension String {
    func date() -> Date {
        let formatter = DateFormatter()
        
        return formatter.date(from: self) ?? Date()
    }
}
