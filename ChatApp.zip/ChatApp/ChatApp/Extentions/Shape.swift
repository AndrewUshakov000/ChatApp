//
//  Shapre.swift
//  Chat
//
//  Created by Andrew Ushakov on 7/24/22.
//

import SwiftUI

struct RoundedShape: Shape {
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: [.bottomLeft, .bottomRight], cornerRadii: CGSize(width: 32, height: 32))
        
        return Path(path.cgPath)
    }
}


