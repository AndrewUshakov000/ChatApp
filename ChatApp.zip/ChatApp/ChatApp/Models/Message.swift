//
//  Message.swift
//  Chat
//
//  Created by Andrew Ushakov on 8/2/22.
//

import Foundation
import FirebaseFirestoreSwift

struct Message: Codable, Identifiable {
    @DocumentID var id: String?

    var fromId: String
    var toId: String
    var text: String
    var timestamp: Date
}
