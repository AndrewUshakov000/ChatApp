//
//  User.swift
//  Chat
//
//  Created by Andrew Ushakov on 8/8/22.
//

import Foundation
import FirebaseFirestoreSwift

struct User: Codable, Identifiable {
    @DocumentID var id: String?

    var uid: String
    var profileImageURL: String
    var email: String

    static var `default` = User(uid: "None", profileImageURL: "None", email: "None")
}
