//
//  RecentMessage.swift
//  Chat
//
//  Created by Andrew Ushakov on 8/21/22.
//

import Foundation
import FirebaseFirestoreSwift

struct RecentMessage: Codable, Identifiable, Hashable {
    @DocumentID var id: String?

    let text: String
    let profileImageURL: String
    let email: String
    let fromId: String
    let toId: String
    let timestamp: Date

    var time: String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: timestamp, relativeTo: Date())
    }
}
