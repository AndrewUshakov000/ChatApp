//
//  AuthController.swift
//  Chat
//
//  Created by Andrew Ushakov on 10/15/22.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseFirestoreSwift

class AuthController: NSObject, ObservableObject {
    let auth: Auth
    let storage: Storage
    let firestore: Firestore

    @Published var user: User?
    @Published var users = [User]()

    @Published var recentMessageListener: ListenerRegistration?
    @Published var recentMessages: [RecentMessage] = []

    @Published var errorMessage: String?

    override init() {
        self.auth = Auth.auth()
        self.storage = Storage.storage()
        self.firestore = Firestore.firestore()

        super.init()

        fetchCurrentUser()
        fetchUsers()
        fetchRecentMessages()
    }

    func login(withEmail email: String, password: String) {
       auth.signIn(withEmail: email, password: password) { _, error in
           if let error = error {
               self.errorMessage = error.localizedDescription
               return
            }

           self.fetchCurrentUser()
           self.fetchUsers()
           self.fetchRecentMessages()
        }
    }

    func register(withEmail email: String, password: String, username: String, image: UIImage) {
        auth.createUser(withEmail: email, password: password) { _, error in
            if let error = error {
                self.errorMessage = error.localizedDescription
                return
            }

            self.persistImageToStorage(image: image)
        }
    }

    func persistImageToStorage(image: UIImage) {
        guard let uid = auth.currentUser?.uid else { return }
        let reference = storage.reference(withPath: uid)
        guard let imageData = image.jpegData(compressionQuality: 0.5) else { return }

        reference.putData(imageData, metadata: nil) { _, error in
            if let error = error {
                print(error)
            }

            reference.downloadURL { url, error in
                if let error = error {
                    print(error)
                    return
                }

                guard let url = url else { return }

                self.storeUserInformation(imageProfileURL: url)
            }
        }
    }

    func signOut() {
        users.removeAll()
        user = nil
        recentMessages.removeAll()
        recentMessageListener?.remove()

        try? auth.signOut()
    }

    func storeUserInformation(imageProfileURL: URL) {
        guard let uid = auth.currentUser?.uid else { return }
        guard let email = auth.currentUser?.email else { return }

        let userData = ["email": email, "uid": uid, "profileImageURL": imageProfileURL.absoluteString]

        firestore.collection("users").document(uid).setData(userData) { error in
            if let error = error {
                print(error.localizedDescription)
                return
            }

            print("User data was successfuly uploaded!")

            self.user = User(uid: uid, profileImageURL: imageProfileURL.absoluteString, email: email)
            self.fetchUsers()
        }
    }

    func fetchCurrentUser() {
        guard let uid = auth.currentUser?.uid else { return }

        firestore.collection("users").document(uid).getDocument { snapshop, error in
            if let error = error {
                print(error)
                return
            }

            guard let data = snapshop?.data() else {
                print("No data found")
                return
            }

            let uid = data["uid"] as? String ?? ""
            let profileImageURL = data["profileImageURL"] as? String ?? ""
            let email = data["email"] as? String ?? ""

            self.user = User(uid: uid, profileImageURL: profileImageURL, email: email)
        }
    }

    func fetchUsers() {
        users.removeAll()

        guard let uid = auth.currentUser?.uid else { return }

        firestore.collection("users").getDocuments { querySnapshot, error in
            if let error = error {
                print(error)
                return
            }

            querySnapshot?.documents.forEach({ snapshot in
                do {
                    let data = try snapshot.data(as: User.self)

                    if uid != data.uid {
                        self.users.append(data)
                    }
                } catch {
                    print(error)
                }
            })
        }
    }

    func fetchRecentMessages() {
        recentMessages.removeAll()

        guard let uid = auth.currentUser?.uid else { return }

        self.recentMessageListener = firestore
            .collection("recent_messages")
            .document(uid)
            .collection("messages")
            .order(by: "timestamp")
            .addSnapshotListener { querySnapshot, error in
                if let error = error {
                    print(error)
                    return
            }

            querySnapshot?.documentChanges.forEach({ change in
                let documentID = change.document.documentID

                if let index = self.recentMessages.firstIndex(where: { recentMessage in
                    return recentMessage.id == documentID
                }) {
                    self.recentMessages.remove(at: index)
                }

                do {
                    let recentMessage = try change.document.data(as: RecentMessage.self)
                    self.recentMessages.insert(recentMessage, at: 0)

                    self.recentMessages.removeDuplicates()
                } catch {
                    print(error)
                }
            })
        }
    }
}
