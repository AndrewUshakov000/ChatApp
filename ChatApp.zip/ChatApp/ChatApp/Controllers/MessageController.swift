//
//  MessageController.swift
//  Chat
//
//  Created by Andrew Ushakov on 10/15/22.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseFirestoreSwift

class MessageController: NSObject, ObservableObject {
    let auth: Auth
    let firestore: Firestore

    @Published var messageListener: ListenerRegistration?

    @Published var messages: [Message] = []
    @Published var scrollId = ""

    override init() {
        self.auth = Auth.auth()
        self.firestore = Firestore.firestore()

        super.init()
    }

    func sendMessages(text: String, sender: User, recipient: User) {
        guard let fromId = auth.currentUser?.uid else { return }
        let toId = recipient.uid

        let myDocument = firestore.collection("messages").document(fromId).collection(toId).document()

        let newMessage = ["fromId": fromId, "toId": toId, "text": text, "timestamp": Timestamp()] as [String: Any]

        myDocument.setData(newMessage) { error in
            if let error = error {
                print("Error adding message to Firestore: \(error)")
            }
        }

        let recipientDocument = firestore.collection("messages").document(toId).collection(fromId).document()

        recipientDocument.setData(newMessage) { error in
            if let error = error {
                print("Error adding message to Firestore: \(error)")
            }
        }

        self.persistRecentMessage(text: text, sender: sender, recipient: recipient)

    }

    func persistRecentMessage(text: String, sender: User, recipient: User) {
        guard let fromId = auth.currentUser?.uid else { return }
        let toId = recipient.uid

        let ourDocument = firestore.collection("recent_messages")
            .document(fromId)
            .collection("messages")
            .document(toId)

        let recepientDocument = firestore
            .collection("recent_messages")
            .document(toId).collection("messages")
            .document(fromId)

        let ourData = [
            "timestamp": Timestamp(),
            "text": text,
            "fromId": fromId,
            "toId": toId,
            "profileImageURL": recipient.profileImageURL,
            "email": recipient.email
        ] as [String: Any]

        let theirData = [
            "timestamp": Timestamp(),
            "text": text,
            "fromId": toId,
            "toId": fromId,
            "profileImageURL": sender.profileImageURL,
            "email": sender.email
        ] as [String: Any]

        ourDocument.setData(ourData) { error in
            if let error = error {
                print(error)
                return
            }
        }

        recepientDocument.setData(theirData) { error in
            if let error = error {
                print(error)
                return
            }
        }
    }

    func fetchMessages(recipient: User) {
        messages.removeAll()

        guard let fromId = auth.currentUser?.uid else { return }
        let toId = recipient.uid

        self.messageListener = firestore
            .collection("messages")
            .document(fromId)
            .collection(toId)
            .order(by: "timestamp")
            .addSnapshotListener { querySnapshot, error in
                if let error = error {
                    print(error)
                    return
            }

            querySnapshot?.documentChanges.forEach({ change in
                if change.type == .added {
                    do {
                        let data = try change.document.data(as: Message.self)
                        self.messages.append(data)
                    } catch {
                        print(error)
                    }
                }
            })

            DispatchQueue.main.async {
                self.scrollId = "Empty"
            }
        }
    }

    func deleteMessageData() {
        messages.removeAll()
    }
}
