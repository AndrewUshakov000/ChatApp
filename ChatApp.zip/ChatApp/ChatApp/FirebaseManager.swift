//
//  FirebaseManager.swift
//  Chat
//
//  Created by Andrew Ushakov on 8/18/22.
//

import Foundation
import Firebase
import FirebaseStorage
import FirebaseFirestoreSwift
import UIKit

class FirebaseManager: NSObject, ObservableObject {

    let auth: Auth
    let storage: Storage
    let firestore: Firestore

    @Published var messageListener: ListenerRegistration?
    @Published var recentMessageListener: ListenerRegistration?

    @Published var errorMessage: String?
    
    @Published var user: User?
    @Published var users = [User]()

    @Published var messages: [Message] = []
    @Published var recentMessages: [RecentMessage] = []
    @Published var scrollId = ""

    override init() {        
        self.auth = Auth.auth()
        self.storage = Storage.storage()
        self.firestore = Firestore.firestore()
        
        super.init()
        
        fetchCurrentUser()
        fetchUsers()
        fetchRecentMessages()
    }
    
    // Every function linked to authentication
    
    func login(withEmail email: String, password: String) {
       auth.signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                self.errorMessage = error.localizedDescription
                return
            }
                        
           self.fetchCurrentUser()
           self.fetchUsers()
           self.fetchRecentMessages()
        }
    }
    
    func register(withEmail email: String, password: String, username: String, image: UIImage) {
        auth.createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                self.errorMessage = error.localizedDescription
                return
            }

            self.persistImageToStorage(image: image)
        }
    }
    
    func persistImageToStorage(image: UIImage) {
        guard let uid = auth.currentUser?.uid else { return }
        let reference = storage.reference(withPath: uid)
        guard let imageData = image.jpegData(compressionQuality: 0.5) else { return }

        reference.putData(imageData, metadata: nil) { metadata, error in
            if let error = error {
                print(error.localizedDescription)
            }
            
            reference.downloadURL { url, error in
                if let error = error {
                    print(error.localizedDescription)
                    return
                }
                
                guard let url = url else { return }

                self.storeUserInformation(imageProfileURL: url)
            }
        }
    }

    func signOut() {
        users.removeAll()
        messages.removeAll()
        recentMessages.removeAll()
        user = nil
        recentMessageListener?.remove()

        try? auth.signOut()
    }
    
    func storeUserInformation(imageProfileURL: URL) {
        guard let uid = auth.currentUser?.uid else { return }
        guard let email = auth.currentUser?.email else { return }

        let userData = ["email": email, "uid": uid, "profileImageURL": imageProfileURL.absoluteString]
        firestore.collection("users").document(uid).setData(userData) { error in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            
            print("User data was successfuly uploaded!")
            
            self.user = User(uid: uid, profileImageURL: imageProfileURL.absoluteString, email: email)
            self.fetchUsers()
        }
    }
    
    func fetchCurrentUser() {
        guard let uid = auth.currentUser?.uid else { return }
        
        firestore.collection("users").document(uid).getDocument { snapshop, error in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            
            guard let data = snapshop?.data() else {
                print("No data found")
                return
            }
            
            let uid = data["uid"] as? String ?? ""
            let profileImageURL = data["profileImageURL"] as? String ?? ""
            let email = data["email"] as? String ?? ""

            
            self.user = User(uid: uid, profileImageURL: profileImageURL, email: email)
        }
    }
    
    func fetchUsers() {
        users.removeAll()

        guard let uid = auth.currentUser?.uid else { return }

        firestore.collection("users").getDocuments { querySnapshot, error in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            
            querySnapshot?.documents.forEach({ snapshot in
                do {
                    let data = try snapshot.data(as: User.self)
                    
                    if uid != data.uid {
                        self.users.append(data)
                    }
                } catch {
                    print(error.localizedDescription)
                }
            })
        }
    }
    
    func fetchMessages(recipient: User) {
        messages.removeAll()
    
        guard let fromId = auth.currentUser?.uid else { return }
        let toId = recipient.uid
        
        self.messageListener = firestore.collection("messages").document(fromId).collection(toId).order(by: "timestamp").addSnapshotListener { querySnapshot, error in
            if let error = error {
                print(error.localizedDescription)
                return
            }

            querySnapshot?.documentChanges.forEach({ change in
                if change.type == .added {
                    do {
                        let data = try change.document.data(as: Message.self)
                        self.messages.append(data)
                    } catch {
                        print(error.localizedDescription)
                    }
                }
            })
            
            DispatchQueue.main.async {
                self.scrollId = "Empty"
            }
        }
    }
    
    func sendMessages(text: String, recipient: User) {
        guard let fromId = auth.currentUser?.uid else { return }
        let toId = recipient.uid
        
        let myDocument = firestore.collection("messages").document(fromId).collection(toId).document()
        
        let newMessage = ["fromId": fromId, "toId": toId, "text": text, "timestamp": Timestamp()] as [String : Any]

        myDocument.setData(newMessage) { error in
            if let error = error {
                print("Error adding message to Firestore: \(error)")
            }
        }
        
        let recipientDocument = firestore.collection("messages").document(toId).collection(fromId).document()
        
        recipientDocument.setData(newMessage) { error in
            if let error = error {
                print("Error adding message to Firestore: \(error)")
            }
        }
        
        self.persistRecentMessage(text: text, recipient: recipient)

    }
    
    func persistRecentMessage(text: String, recipient: User) {
        guard let fromId = auth.currentUser?.uid else { return }
        let toId = recipient.uid

        let ourDocument = firestore.collection("recent_messages").document(fromId).collection("messages").document(toId)
        
        let recepientDocument = firestore.collection("recent_messages").document(toId).collection("messages").document(fromId)
        
        let ourData = [
            "timestamp": Timestamp(),
            "text": text,
            "fromId": fromId,
            "toId": toId,
            "profileImageURL": recipient.profileImageURL,
            "email": recipient.email
        ] as [String: Any]
        
        let theirData = [
            "timestamp": Timestamp(),
            "text": text,
            "fromId": toId,
            "toId": fromId,
            "profileImageURL": user!.profileImageURL,
            "email": user!.email
        ] as [String: Any]

        ourDocument.setData(ourData) { error in
            if let error = error {
                print(error.localizedDescription)
                return
            }
        }
        
        recepientDocument.setData(theirData) { error in
            if let error = error {
                print(error.localizedDescription)
                return
            }
        }
    }
    
    func fetchRecentMessages() {
        recentMessages.removeAll()

        guard let uid = auth.currentUser?.uid else { return }

        self.recentMessageListener = firestore.collection("recent_messages").document(uid).collection("messages").order(by: "timestamp").addSnapshotListener { querySnapshot, error in
            if let error = error {
                print(error.localizedDescription)
                return
            }
            
            querySnapshot?.documentChanges.forEach({ change in
                let documentID = change.document.documentID
                
                if let index = self.recentMessages.firstIndex(where: { recentMessage in
                    return recentMessage.id == documentID
                }) {
                    self.recentMessages.remove(at: index)
                }
                
                do {
                    let recentMessage = try change.document.data(as: RecentMessage.self)
                    self.recentMessages.insert(recentMessage, at: 0)

                    self.recentMessages.removeDuplicates()
                } catch {
                    print(error.localizedDescription)
                }
            })
        }
    }
}
