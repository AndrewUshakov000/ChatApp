//
//  ResetPasswordView.swift
//  Chat
//
//  Created by Andrew Ushakov on 8/22/22.
//

import SwiftUI

struct ResetPasswordView: View {
    @State private var email = ""
    
    @State private var showAlert = false
    @State private var title = ""
    @State private var message = ""

    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var firebaseManager: FirebaseManager
    var body: some View {
        VStack {
            AuthHeaderView(title1: "Forgot your password?", title2: "Don't worry!")
           
            CustomTextField(imageName: "envelope", placeholderText: "Email", secure: false, text: $email)
                .padding(.horizontal, 32)
                .padding(.top, 44)
                        
            Button {
                withAnimation {
                    firebaseManager.auth.sendPasswordReset(withEmail: email) { error in
                        if let error = error {
                            self.title = "Error"
                            self.message = error.localizedDescription
                        } else {
                            self.title = "Success"
                            self.message = "Check your email box. If you don't see a mail, check your spam box."
                        }
                        
                        self.showAlert.toggle()
                    }
                }
            } label: {
                Text("Send a reset link")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 340, height: 50)
                    .background(!email.contains("@gmail.com") ? Color(.systemGray) : Color(.systemBlue))
                    .clipShape(Capsule())
                    .padding()
            }
            .padding(.horizontal, 32)
            .padding(.top, 44)
            .shadow(color: .gray.opacity(0.5),radius: 10)
            .disabled(!email.contains("@gmail.com"))
            
            Spacer()
            
            Button {
                dismiss()
            } label: {
                HStack {
                    Text("Reminisced your password?")
                        .font(.body)
                    
                    Text("Sign in")
                        .font(.body)
                        .fontWeight(.semibold)
                    
                }
            }
            .padding(.bottom, 32)
            .foregroundColor(Color(.systemBlue))

        }
        .ignoresSafeArea()
        .navigationBarBackButtonHidden()
        .alert(isPresented: $showAlert) {
            Alert(title: Text(title), message: Text(message), dismissButton: title == "Error" ? .default(Text("OK")) : .default(Text("Ok"), action: {
                dismiss()
            }))
        }
        
    }
}

struct ResetPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ResetPasswordView()
    }
}
