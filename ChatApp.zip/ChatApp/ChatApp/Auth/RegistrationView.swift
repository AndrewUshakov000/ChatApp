//
//  RegistrationView.swift
//  Chat
//
//  Created by Andrew Ushakov on 7/25/22.
//

import SwiftUI
import PhotosUI

struct RegistrationView: View {
    @State private var email = ""
    @State private var username = ""
    @State private var password = ""

    @State private var selection: PhotosPickerItem? = nil
    @State private var selectedImageData: Data? = nil
    
    @State private var showError = false

    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var firebaseManager: FirebaseManager

    var body: some View {
        VStack {
            AuthHeaderView(title1: "Get started.", title2: "Create your account")
            
            VStack(spacing: 40) {
                PhotosPicker(selection: $selection, matching: .images) {
                    if selectedImageData != nil {
                        Image(uiImage: UIImage(data: selectedImageData!)!)
                            .resizable()
                            .clipShape(Circle())
                            .frame(width: 120, height: 120)
                            .overlay(
                                Circle().stroke(lineWidth: 2)
                            )
                            .foregroundColor(Color(.label))
                    } else {
                        Image(systemName: "person.fill")
                            .resizable()
                            .frame(width: 70, height: 70)
                            .padding(30)
                            .overlay(
                                Circle().stroke(lineWidth: 2)
                            )
                            .foregroundColor(Color(.label))
                    }
                }
                
                CustomTextField(imageName: "envelope", placeholderText: "Email", secure: false, text: $email)
                
                CustomTextField(imageName: "person", placeholderText: "Username", secure: false, text: $username)
                                    
                CustomTextField(imageName: "lock", placeholderText: "Password", secure: true, text: $password)
            }
            .padding(32)
            
            
            Button {
                firebaseManager.register(withEmail: email, password: password, username: username, image: UIImage(data: selectedImageData!)!)

                if firebaseManager.errorMessage != nil {
                    self.showError.toggle()
                }
            } label: {
                Text("Sign up")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 340, height: 50)
                    .background(selectedImageData == nil ? Color(.systemGray) : Color(.systemBlue))
                    .clipShape(Capsule())
                    .padding()
            }
            .shadow(color: .gray.opacity(0.5),radius: 10)
            .disabled(selectedImageData == nil)
            
            Spacer()
            
            Button {
                dismiss()
            } label: {
                HStack {
                    Text("Already have an account?")
                        .font(.body)
                    
                    Text("Sign in")
                        .font(.body)
                        .fontWeight(.semibold)
                    
                }
            }
            .foregroundColor(Color(.systemBlue))
            
        }
        .navigationBarBackButtonHidden()
        .ignoresSafeArea()
        .onChange(of: selection) { newValue in
            Task {
                // Retrive selected asset in the form of Data
                if let data = try? await newValue?.loadTransferable(type: Data.self) {
                    selectedImageData = data
                }
            }
        }
        .alert(isPresented: $showError) {
            Alert(title: Text("Error"), message: Text(firebaseManager.errorMessage!), dismissButton: .default(Text("OK"), action: {
                firebaseManager.errorMessage = nil
            }))
        }
    }
}

struct RegistrationView_Previews: PreviewProvider {
    static var previews: some View {
        RegistrationView()
    }
}
