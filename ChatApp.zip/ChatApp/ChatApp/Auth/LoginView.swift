//
//  LoginView.swift
//  Chat
//
//  Created by Andrew Ushakov on 7/25/22.
//

import SwiftUI

struct LoginView: View {
    @EnvironmentObject var authController: AuthController

    @State private var email = ""
    @State private var password = ""
    @State private var showError = false

    var body: some View {
        NavigationStack {
            VStack {
                AuthHeaderView(title1: "Hello.", title2: "Welcome Back")

                VStack(spacing: 40) {
                    CustomTextField(text: $email, imageName: "envelope", placeholderText: "Email", secure: false)

                    CustomTextField(text: $password, imageName: "lock", placeholderText: "Password", secure: true)
                }
                .padding(.horizontal, 32)
                .padding(.top, 44)

                HStack {
                    Spacer()

                    NavigationLink {
                        ResetPasswordView()
                    } label: {
                        Text("Forgot password")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(Color(.systemBlue))
                            .padding(.top)
                            .padding(.trailing, 24)
                    }
                }

                Button {
                    authController.login(withEmail: email, password: password)

                    if authController.errorMessage != nil {
                        self.showError.toggle()
                    }
                } label: {
                    Text("Sign in")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 340, height: 50)
                        .background(Color(.systemBlue))
                        .clipShape(Capsule())
                        .padding()
                }
                .shadow(color: .gray.opacity(0.5), radius: 10)

                Spacer()

                NavigationLink {
                    RegistrationView()
                } label: {
                    HStack {
                        Text("Don't have an account?")
                            .font(.body)

                        Text("Sign up")
                            .font(.body)
                            .fontWeight(.semibold)

                    }
                }
                .padding(.bottom, 32)
                .foregroundColor(Color(.systemBlue))

            }
            .ignoresSafeArea()
            .alert(isPresented: $showError) {
                Alert(
                    title: Text("Error"),
                    message: Text(authController.errorMessage!),
                    dismissButton: .default(Text("OK"), action: {
                        authController.errorMessage = nil
                    })
                )
            }
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
