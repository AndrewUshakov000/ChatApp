//
//  Settings.swift
//  Chat
//
//  Created by Andrew Ushakov on 7/24/22.
//

import SwiftUI

struct Settings: View {
    static let tag: String? = "Settings"

    var body: some View {
        Image("meme")
            .resizable()
            .aspectRatio(contentMode: .fit)
    }
}

struct Settings_Previews: PreviewProvider {
    static var previews: some View {
        Settings()
    }
}
